/*
 * Lab 6 - Program 6.1: Motorbike, a concrete Vehicle
 * Author: Privilege
 */

class Motorbike extends Vehicle {
    Motorbike(String plate) { super(plate); }
    @Override double fuelCostPerKm() { return 0.15; }
}
