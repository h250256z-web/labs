/*
 * Lab 6 - Exercise 1 (Basic): abstract Shape with Circle, Rectangle and Square
 * Author: Privilege
 */
abstract class Shape {
    abstract double area();          // EXPLAIN: no body, each shape must provide one
    abstract double perimeter();
}

class Circle extends Shape {
    double r;
    Circle(double r) { this.r = r; }
    @Override double area()      { return Math.PI * r * r; }
    @Override double perimeter() { return 2 * Math.PI * r; }
}

class Rectangle extends Shape {
    double w, h;
    Rectangle(double w, double h) { this.w = w; this.h = h; }
    @Override double area()      { return w * h; }
    @Override double perimeter() { return 2 * (w + h); }
}

class Square extends Shape {
    double side;
    Square(double side) { this.side = side; }
    @Override double area()      { return side * side; }
    @Override double perimeter() { return 4 * side; }
}

public class ShapesAbstract {
    public static void main(String[] args) {
        Shape[] shapes = { new Circle(2), new Rectangle(3, 5), new Square(4) };
        for (Shape s : shapes) {
            System.out.printf("%s: area %.2f, perimeter %.2f%n",
                    s.getClass().getSimpleName(), s.area(), s.perimeter());
        }
        // new Shape();   // COMPILE ERROR: Shape is abstract
    }
}
