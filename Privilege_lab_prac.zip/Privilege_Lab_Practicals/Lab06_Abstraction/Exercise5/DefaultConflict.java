/*
 * Lab 6 - Exercise 5 (Challenge): two interfaces with the same default method
 * Author: Privilege
 */
interface Greeter {
    default void hello() { System.out.println("Hello from Greeter"); }
}

interface Waver {
    default void hello() { System.out.println("Hello from Waver"); }
}

// RULE: if a class inherits two defaults with the same signature, the compiler refuses
// until the class overrides the method. The override can pick one of them with X.super.
class Friendly implements Greeter, Waver {
    @Override
    public void hello() {
        Greeter.super.hello();   // choose Greeter's version explicitly
        Waver.super.hello();     // and then Waver's version
    }
}

public class DefaultConflict {
    public static void main(String[] args) {
        new Friendly().hello();
    }
}
