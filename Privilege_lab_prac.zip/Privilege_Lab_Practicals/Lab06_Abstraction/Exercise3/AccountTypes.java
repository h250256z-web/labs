/*
 * Lab 6 - Exercise 3 (Intermediate): abstract Account with two kinds of account
 * Author: Privilege
 */
abstract class Account {
    protected double balance;

    // Shared behaviour: written once, inherited by every account type
    void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
        balance += amount;
    }

    // Each account type must say how much it charges each month
    abstract double monthlyFee();

    void endOfMonth() {
        balance -= monthlyFee();
    }

    double getBalance() { return balance; }
}

class SavingsAccount extends Account {
    @Override double monthlyFee() { return 2.0; }   // low fee
}

class CurrentAccount extends Account {
    @Override double monthlyFee() { return 5.0; }   // higher fee, but no interest rules
}

public class AccountTypes {
    public static void main(String[] args) {
        Account[] accounts = { new SavingsAccount(), new CurrentAccount() };
        for (Account a : accounts) {
            a.deposit(100);
            a.endOfMonth();
            System.out.println(a.getClass().getSimpleName() + " balance after one month: " + a.getBalance());
        }
    }
}
