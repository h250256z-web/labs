/*
 * Lab 6 - Exercise 2 (Basic): Flyable interface for unrelated classes
 * Author: Privilege
 */
interface Flyable {
    void fly();
}

// Bird and Aeroplane share no superclass, but both can fly
class Bird implements Flyable {
    @Override public void fly() { System.out.println("Bird flaps and glides"); }
}

class Aeroplane implements Flyable {
    @Override public void fly() { System.out.println("Aeroplane taxis, takes off and climbs"); }
}

public class FlyingThings {
    public static void main(String[] args) {
        Flyable[] sky = { new Bird(), new Aeroplane() };
        for (Flyable f : sky) {
            f.fly();   // EXPLAIN: the interface is the only thing these two have in common
        }
    }
}
