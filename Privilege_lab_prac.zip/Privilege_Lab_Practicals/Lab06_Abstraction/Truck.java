/*
 * Lab 6 - Program 6.1: Truck, a concrete Vehicle
 * Author: Privilege
 */

class Truck extends Vehicle {
    Truck(String plate) { super(plate); }
    @Override double fuelCostPerKm() { return 0.80; }
}
