/*
 * Lab 6 - Exercise 4 (Intermediate): Comparable (natural order) and Comparator (another order)
 * Author: Privilege
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Student implements Comparable<Student> {
    String name;
    int marks;
    Student(String name, int marks) { this.name = name; this.marks = marks; }

    // EXPLAIN: the natural order is by name
    @Override public int compareTo(Student other) {
        return name.compareTo(other.name);
    }

    @Override public String toString() { return name + "(" + marks + ")"; }
}

public class StudentSorting {
    public static void main(String[] args) {
        List<Student> list = new ArrayList<>(List.of(
            new Student("Zodwa", 61), new Student("Anesu", 88), new Student("Mufaro", 74)));

        list.sort(null);                       // null means "use compareTo", the natural order
        System.out.println("By name:  " + list);

        // EXPLAIN: a Comparator gives a second ordering without changing the class
        list.sort(Comparator.comparingInt((Student s) -> s.marks).reversed());
        System.out.println("By marks: " + list);
    }
}
