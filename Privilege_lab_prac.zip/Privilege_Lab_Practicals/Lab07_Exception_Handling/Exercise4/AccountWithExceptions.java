/*
 * Lab 7 - Exercise 4 (Intermediate): withdraw throws instead of returning false
 * Author: Privilege
 *
 * TRADE-OFFS (my notes):
 *  + the caller cannot ignore a failed withdrawal by accident
 *  + the reason and the shortfall can be carried inside the exception
 *  - callers must write try/catch, which makes simple code longer
 *  - a boolean is quicker for an expected, everyday outcome; an exception is better when
 *    failure is unusual and needs explaining
 */
class InsufficientFundsException extends Exception {
    private final double shortfall;
    InsufficientFundsException(String message, double shortfall) {
        super(message);
        this.shortfall = shortfall;
    }
    double getShortfall() { return shortfall; }
}

class Account {
    private double balance;
    Account(double balance) { this.balance = balance; }

    void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException("Balance too low", amount - balance);
        }
        balance -= amount;
    }

    double getBalance() { return balance; }
}

public class AccountWithExceptions {
    public static void main(String[] args) {
        Account acc = new Account(100);
        try {
            acc.withdraw(40);
            acc.withdraw(90);          // fails
        } catch (InsufficientFundsException e) {
            System.out.println(e.getMessage() + ", short by " + e.getShortfall());
        }
        System.out.println("Balance: " + acc.getBalance());
    }
}
