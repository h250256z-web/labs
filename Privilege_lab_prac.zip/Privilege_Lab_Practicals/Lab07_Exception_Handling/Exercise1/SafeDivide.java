/*
 * Lab 7 - Exercise 1 (Basic): divide two numbers typed by the user
 * Author: Privilege
 */
import java.util.Scanner;

public class SafeDivide {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        try {
            System.out.print("First number: ");
            int a = Integer.parseInt(in.nextLine().trim());     // bad text -> NumberFormatException
            System.out.print("Second number: ");
            int b = Integer.parseInt(in.nextLine().trim());
            System.out.println(a + " / " + b + " = " + (a / b)); // zero -> ArithmeticException
        } catch (NumberFormatException e) {
            System.out.println("Please type whole numbers only.");
        } catch (ArithmeticException e) {
            System.out.println("You cannot divide by zero.");
        }
        System.out.println("Program finished.");
    }
}
