/*
 * Lab 7 - Exercise 3 (Intermediate): a custom checked exception for age
 * Author: Privilege
 */
class InvalidAgeException extends Exception {
    InvalidAgeException(String message) { super(message); }
}

public class AgeValidation {

    // EXPLAIN: 'throws' means the caller must handle InvalidAgeException (it is checked)
    static void validateAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 120) {
            throw new InvalidAgeException("Age " + age + " is outside 0 to 120");
        }
        System.out.println("Age " + age + " is valid");
    }

    public static void main(String[] args) {
        int[] ages = {25, -3, 130, 0, 120};
        for (int a : ages) {
            try {
                validateAge(a);
            } catch (InvalidAgeException e) {
                System.out.println("Invalid: " + e.getMessage());
            }
        }
    }
}
