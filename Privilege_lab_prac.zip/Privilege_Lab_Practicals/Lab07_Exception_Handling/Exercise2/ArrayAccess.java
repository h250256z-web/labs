/*
 * Lab 7 - Exercise 2 (Basic): reading an array element safely
 * Author: Privilege
 */
public class ArrayAccess {

    static int elementAt(int[] data, int index) {
        try {
            return data[index];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Index " + index + " is outside the array, returning -1");
            return -1;
        }
    }

    public static void main(String[] args) {
        int[] scores = {55, 72, 90};
        System.out.println("Element 1: " + elementAt(scores, 1));
        System.out.println("Element 9: " + elementAt(scores, 9));
    }
}
