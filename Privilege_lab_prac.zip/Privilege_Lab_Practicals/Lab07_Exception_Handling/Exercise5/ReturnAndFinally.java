/*
 * Lab 7 - Exercise 5 (Challenge): return inside try, print inside finally
 * Author: Privilege
 */
public class ReturnAndFinally {

    static int tricky() {
        try {
            System.out.println("in try: about to return 1");
            return 1;                    // the value 1 is saved here...
        } finally {
            System.out.println("in finally: runs before the method really exits");
            // ...and finally still runs before control leaves the method
        }
    }

    public static void main(String[] args) {
        // PREDICTION: "in try", then "in finally", then 1
        System.out.println("returned: " + tricky());
    }
}
