/*
 * Lab 10 - Exercise 5 (Challenge): group learners by grade band and write one file per band
 * Author: Privilege
 *
 * Bands used here: A = 3.5 and above, B = 2.5 to 3.49, C = below 2.5.
 */
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

record Learner(String name, int roll, double gpa) {
    String toCsv() { return name + "," + roll + "," + gpa; }
    static Learner fromCsv(String line) {
        String[] p = line.split(",");
        return new Learner(p[0], Integer.parseInt(p[1]), Double.parseDouble(p[2]));
    }
}

public class GradeBandFiles {

    static String band(Learner l) {
        if (l.gpa() >= 3.5) return "A";
        if (l.gpa() >= 2.5) return "B";
        return "C";
    }

    public static void main(String[] args) throws IOException {
        // Step 1: write a learners.csv so the program can run on its own
        Path source = Path.of("learners.csv");
        Files.write(source, List.of(
            new Learner("Tariro", 101, 3.8).toCsv(),
            new Learner("Farai", 102, 2.9).toCsv(),
            new Learner("Rudo", 103, 3.9).toCsv(),
            new Learner("Kuda", 104, 2.1).toCsv(),
            new Learner("Mufaro", 105, 3.6).toCsv()));

        // Step 2: read them back and group by band (TreeMap keeps the bands in order)
        List<Learner> learners = Files.readAllLines(source).stream()
            .map(Learner::fromCsv)
            .toList();
        Map<String, List<Learner>> byBand = learners.stream()
            .collect(Collectors.groupingBy(GradeBandFiles::band, TreeMap::new, Collectors.toList()));

        // Step 3: one report file per band
        for (Map.Entry<String, List<Learner>> entry : byBand.entrySet()) {
            List<String> lines = entry.getValue().stream()
                .map(l -> l.name() + " (" + l.gpa() + ")")
                .toList();
            Path out = Path.of("band_" + entry.getKey() + ".txt");
            Files.write(out, lines);
            System.out.println("Wrote " + out + " with " + lines.size() + " learner(s)");
        }
    }
}
