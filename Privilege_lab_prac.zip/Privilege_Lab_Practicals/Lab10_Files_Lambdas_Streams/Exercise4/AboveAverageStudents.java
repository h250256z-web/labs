/*
 * Lab 10 - Exercise 4 (Intermediate): students above the average, sorted by name
 * Author: Privilege
 */
import java.util.List;

record Student(String name, double marks) {}

public class AboveAverageStudents {
    public static void main(String[] args) {
        List<Student> class1 = List.of(
            new Student("Zvikomborero", 58), new Student("Ada", 81),
            new Student("Kudzai", 73), new Student("Bongani", 66), new Student("Chenai", 90));

        double average = class1.stream()
            .mapToDouble(Student::marks)
            .average()
            .orElse(0);
        System.out.printf("Class average: %.1f%n", average);

        class1.stream()
            .filter(s -> s.marks() > average)
            .map(Student::name)
            .sorted()                          // alphabetical
            .forEach(name -> System.out.println("Above average: " + name));
    }
}
