/*
 * Lab 10 - Exercise 3 (Intermediate): count lines, words and characters in a file
 * Author: Privilege
 */
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class FileCounts {
    public static void main(String[] args) throws IOException {
        Path file = Path.of("sample_text.txt");
        // Write a sample file first so the program can run on its own
        Files.writeString(file, "The library opens at eight.\nIt closes at five.\n");

        List<String> lines = Files.readAllLines(file);
        int lineCount = lines.size();
        int wordCount = 0;
        int charCount = 0;
        for (String line : lines) {
            String trimmed = line.trim();
            if (!trimmed.isEmpty()) {
                wordCount += trimmed.split("\\s+").length;   // split on any run of spaces
            }
            charCount += line.length();
        }

        System.out.println("Lines: " + lineCount);
        System.out.println("Words: " + wordCount);
        System.out.println("Characters (excluding line breaks): " + charCount);
    }
}
