/*
 * Lab 10 - Exercise 1 (Basic): save five typed lines, then read them back
 * Author: Privilege
 */
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Scanner;

public class SaveFiveLines {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        List<String> lines = new java.util.ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            System.out.print("Line " + i + ": ");
            lines.add(in.nextLine());
        }

        Path file = Path.of("five_lines.txt");
        try {
            Files.write(file, lines);                       // save
            System.out.println("Read back:");
            for (String line : Files.readAllLines(file)) {  // load
                System.out.println("  " + line);
            }
        } catch (IOException e) {
            System.out.println("File problem: " + e.getMessage());
        }
    }
}
