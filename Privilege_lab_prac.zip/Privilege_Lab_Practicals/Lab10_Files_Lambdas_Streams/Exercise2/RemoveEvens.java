/*
 * Lab 10 - Exercise 2 (Basic): remove even numbers with a Predicate
 * Author: Privilege
 */
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class RemoveEvens {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));

        // EXPLAIN: the predicate says "true for an even number", and removeIf deletes every match
        Predicate<Integer> isEven = n -> n % 2 == 0;
        numbers.removeIf(isEven);

        System.out.println("Odd numbers left: " + numbers);
    }
}
