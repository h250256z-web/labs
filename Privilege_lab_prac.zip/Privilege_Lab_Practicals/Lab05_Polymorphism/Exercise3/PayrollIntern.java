/*
 * Lab 5 - Exercise 3 (Intermediate): adding Intern without changing the payroll loop
 * Author: Privilege
 */
class Employee {
    String name;
    Employee(String name) { this.name = name; }
    double calculatePay() { return 0; }
}

class Manager extends Employee {
    double salary;
    Manager(String name, double salary) { super(name); this.salary = salary; }
    @Override double calculatePay() { return salary; }
}

class Developer extends Employee {
    double hourly;
    int hours;
    Developer(String name, double hourly, int hours) { super(name); this.hourly = hourly; this.hours = hours; }
    @Override double calculatePay() { return hourly * hours; }
}

// NEW CLASS: added without touching the payroll loop below
class Intern extends Employee {
    double stipend;
    Intern(String name, double stipend) { super(name); this.stipend = stipend; }
    @Override double calculatePay() { return stipend; }
}

public class PayrollIntern {
    public static void main(String[] args) {
        Employee[] staff = {
            new Manager("Nyasha", 3500),
            new Developer("Tatenda", 20, 120),
            new Intern("Rumbi", 800)
        };

        double total = 0;
        for (Employee e : staff) {
            total += e.calculatePay();   // the same loop works for every kind of employee
        }
        System.out.println("Total payroll: " + total);
    }
}
