/*
 * Lab 5 - Exercise 4 (Intermediate): method versus field through a superclass reference
 * Author: Privilege
 */
class Parent {
    String label = "parent field";
    static String kind() { return "parent static"; }
    String describe()    { return "parent method"; }
}

class Child extends Parent {
    String label = "child field";                 // hides the parent's field
    static String kind() { return "child static"; }  // hides the parent's static method
    @Override String describe() { return "child method"; }  // overrides
}

public class FieldVersusMethod {
    public static void main(String[] args) {
        Parent p = new Child();    // the object is a Child; the variable type is Parent

        System.out.println("describe(): " + p.describe());  // child method: overriding is polymorphic
        System.out.println("label:      " + p.label);       // parent field: fields use the declared type
        System.out.println("kind():     " + p.kind());      // parent static: statics use the declared type
    }
}
