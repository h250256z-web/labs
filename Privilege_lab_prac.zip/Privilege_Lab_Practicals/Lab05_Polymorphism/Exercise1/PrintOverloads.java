/*
 * Lab 5 - Exercise 1 (Basic): overloaded print methods
 * Author: Privilege
 */
public class PrintOverloads {

    static void print(int value)     { System.out.println("int: " + value); }
    static void print(double value)  { System.out.println("double: " + value); }
    static void print(String value)  { System.out.println("String: " + value); }

    // EXPLAIN: an int[] has a different type, so it needs its own overload
    static void print(int[] values) {
        System.out.print("int array:");
        for (int v : values) System.out.print(" " + v);
        System.out.println();
    }

    public static void main(String[] args) {
        print(42);                      // int version
        print(3.75);                    // double version
        print("Privilege");             // String version
        print(new int[] {1, 2, 3});     // int[] version
    }
}
