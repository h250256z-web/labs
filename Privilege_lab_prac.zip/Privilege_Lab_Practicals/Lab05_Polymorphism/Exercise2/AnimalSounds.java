/*
 * Lab 5 - Exercise 2 (Basic): different animals, one array
 * Author: Privilege
 */
class Animal {
    String sound() { return "..."; }
}

class Cat extends Animal {
    @Override String sound() { return "Meow"; }
}

class Cow extends Animal {
    @Override String sound() { return "Moo"; }
}

class Duck extends Animal {
    @Override String sound() { return "Quack"; }
}

public class AnimalSounds {
    public static void main(String[] args) {
        Animal[] farm = { new Cat(), new Cow(), new Duck() };
        for (Animal a : farm) {
            // EXPLAIN: the loop does not know the subclass, Java picks the right sound at run time
            System.out.println(a.getClass().getSimpleName() + " says " + a.sound());
        }
    }
}
