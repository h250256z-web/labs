/*
 * Lab 5 - Exercise 5 (Challenge): instanceof versus a polymorphic process() method
 * Author: Privilege
 */
class Payment {
    double amount;
    Payment(double amount) { this.amount = amount; }
}

class CardPayment extends Payment {
    CardPayment(double amount) { super(amount); }
}

class MobileMoneyPayment extends Payment {
    String phone;
    MobileMoneyPayment(double amount, String phone) { super(amount); this.phone = phone; }
}

// VERSION 1: one method decides what to do by checking the type of the object.
// Every new payment type means editing this method.
class ProcessorByType {
    static void pay(Payment p) {
        if (p instanceof CardPayment c) {
            System.out.println("Card charge of " + c.amount);
        } else if (p instanceof MobileMoneyPayment m) {
            System.out.println("Mobile money to " + m.phone + " for " + m.amount);
        } else {
            System.out.println("Unknown payment of " + p.amount);
        }
    }
}

// VERSION 2: each payment knows how to process itself. Adding a type needs no change here.
class PolymorphicPayment {
    static class Base {
        double amount;
        Base(double amount) { this.amount = amount; }
        void process() { System.out.println("Generic payment of " + amount); }
    }
    static class Card extends Base {
        Card(double amount) { super(amount); }
        @Override void process() { System.out.println("Card charge of " + amount); }
    }
    static class Mobile extends Base {
        String phone;
        Mobile(double amount, String phone) { super(amount); this.phone = phone; }
        @Override void process() { System.out.println("Mobile money to " + phone + " for " + amount); }
    }
}

public class PaymentProcessor {
    public static void main(String[] args) {
        System.out.println("-- instanceof version --");
        ProcessorByType.pay(new CardPayment(50));
        ProcessorByType.pay(new MobileMoneyPayment(20, "0771234567"));

        System.out.println("-- polymorphic version --");
        PolymorphicPayment.Base[] payments = {
            new PolymorphicPayment.Card(50),
            new PolymorphicPayment.Mobile(20, "0771234567")
        };
        for (PolymorphicPayment.Base p : payments) {
            p.process();   // no type checks needed
        }
        // EXPLAIN: the polymorphic version is easier to extend and has fewer places to forget a case.
    }
}
