/*
 * Lab 8 - Exercise 3 (Intermediate): a generic Stack<T> backed by an ArrayList<T>
 * Author: Privilege
 */
import java.util.ArrayList;
import java.util.List;

class MyStack<T> {
    private final List<T> items = new ArrayList<>();   // EXPLAIN: the type is decided by the user of the class

    void push(T item) { items.add(item); }

    T pop() {
        if (isEmpty()) throw new IllegalStateException("Cannot pop from an empty stack");
        return items.remove(items.size() - 1);
    }

    T peek() {
        if (isEmpty()) throw new IllegalStateException("Cannot peek at an empty stack");
        return items.get(items.size() - 1);
    }

    boolean isEmpty() { return items.isEmpty(); }
    int size()        { return items.size(); }
}

public class GenericStack {
    public static void main(String[] args) {
        MyStack<String> words = new MyStack<>();
        words.push("first");
        words.push("second");
        System.out.println("Peek: " + words.peek());
        System.out.println("Pop:  " + words.pop());
        System.out.println("Pop:  " + words.pop());
        System.out.println("Empty now? " + words.isEmpty());

        MyStack<Integer> numbers = new MyStack<>();   // the same class works for another type
        numbers.push(7);
        System.out.println("Number popped: " + numbers.pop());
    }
}
