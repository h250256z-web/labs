/*
 * Lab 8 - Exercise 1 (Basic): sum, maximum and reverse order of an ArrayList
 * Author: Privilege
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListSumMax {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            numbers.add(i * i % 17);       // ten values, some repeating
        }
        System.out.println("Numbers: " + numbers);

        int sum = 0;
        for (int n : numbers) sum += n;    // autoboxing and unboxing happen here
        System.out.println("Sum: " + sum);
        System.out.println("Max: " + Collections.max(numbers));

        List<Integer> reversed = new ArrayList<>(numbers);
        Collections.reverse(reversed);      // reverses the copy, not the original
        System.out.println("Reversed: " + reversed);
    }
}
