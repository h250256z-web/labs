/*
 * Lab 8 - Exercise 4 (Intermediate): word frequency, most frequent first
 * Author: Privilege
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SortedWordCount {
    public static void main(String[] args) {
        String paragraph = "the rain fell on the roof and the roof leaked near the door";

        Map<String, Integer> counts = new HashMap<>();
        for (String word : paragraph.split(" ")) {
            counts.merge(word, 1, Integer::sum);   // add one, or start at one
        }

        // EXPLAIN: a map is not ordered, so I copy the entries into a list and sort that list
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((a, b) -> {
            int byCount = b.getValue().compareTo(a.getValue());    // higher count first
            return byCount != 0 ? byCount : a.getKey().compareTo(b.getKey());  // then alphabetical
        });

        for (Map.Entry<String, Integer> e : entries) {
            System.out.println(e.getKey() + " : " + e.getValue());
        }
    }
}
