/*
 * Lab 8 - Exercise 5 (Challenge): a generic bubble sort
 * Author: Privilege
 */
import java.util.Arrays;

public class GenericBubbleSort {

    // EXPLAIN: T extends Comparable<T> means compareTo is available for every element
    static <T extends Comparable<T>> void bubbleSort(T[] arr) {
        for (int pass = 0; pass < arr.length - 1; pass++) {
            for (int i = 0; i < arr.length - 1 - pass; i++) {
                if (arr[i].compareTo(arr[i + 1]) > 0) {
                    T temp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        Integer[] numbers = {42, 7, 19, 3, 25};
        bubbleSort(numbers);
        System.out.println("Integers: " + Arrays.toString(numbers));

        String[] words = {"pear", "apple", "mango"};
        bubbleSort(words);
        System.out.println("Strings:  " + Arrays.toString(words));

        // WHY NOT int[]?  A primitive int is not an object, so it cannot be a T,
        // and an int[] is not a T[]. Use Integer[] (boxed values) instead.
    }
}
