/*
 * Lab 8 - Exercise 2 (Basic): removing duplicate names with a Set
 * Author: Privilege
 */
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class UniqueNames {
    public static void main(String[] args) {
        List<String> names = List.of("Tapiwa", "Ruva", "Tapiwa", "Chipo", "Ruva", "Tinotenda");

        // EXPLAIN: a Set refuses duplicates; LinkedHashSet also keeps the first-seen order
        Set<String> unique = new LinkedHashSet<>(names);
        System.out.println("Original: " + names);
        System.out.println("Unique:   " + unique);
    }
}
