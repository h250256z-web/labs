/*
 * Lab 4 - Exercise 1 (Basic): Student extends Person and reuses display()
 * Author: Privilege
 */
class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void display() {
        System.out.println("Name: " + name + ", age " + age);
    }
}

class Student extends Person {
    String course;

    Student(String name, int age, String course) {
        super(name, age);          // EXPLAIN: Person's constructor sets name and age
        this.course = course;
    }

    void showCourse() {
        System.out.println(name + " is studying " + course);
    }
}

public class StudentPerson {
    public static void main(String[] args) {
        Person p = new Person("Tatenda", 45);
        Student s = new Student("Privilege", 20, "OOP");

        p.display();
        s.display();        // EXPLAIN: display() is inherited, not rewritten in Student
        s.showCourse();
    }
}
