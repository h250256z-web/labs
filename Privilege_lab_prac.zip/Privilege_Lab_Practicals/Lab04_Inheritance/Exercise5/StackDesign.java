/*
 * Lab 4 - Exercise 5 (Challenge): inheritance versus composition for a Stack
 * Author: Privilege
 */
import java.util.ArrayList;

// BAD DESIGN: extends ArrayList, so every list method is exposed to callers
class BadStack extends ArrayList<Integer> {
    void push(int x) { add(x); }
    int pop()        { return remove(size() - 1); }
}

// BETTER DESIGN: a Stack HAS a list. Only stack operations are visible.
class Stack {
    private final ArrayList<Integer> items = new ArrayList<>();

    void push(int x) { items.add(x); }

    int pop() {
        if (items.isEmpty()) throw new IllegalStateException("Stack is empty");
        return items.remove(items.size() - 1);
    }

    int peek() {
        if (items.isEmpty()) throw new IllegalStateException("Stack is empty");
        return items.get(items.size() - 1);
    }

    boolean isEmpty() { return items.isEmpty(); }
}

public class StackDesign {
    public static void main(String[] args) {
        BadStack bad = new BadStack();
        bad.push(1);
        bad.push(2);
        bad.add(0, 99);                     // EXPLAIN: a list method breaks the stack rule
        System.out.println("Bad stack pop: " + bad.pop() + " (expected 2)");
        System.out.println("Bad stack bottom item is now " + bad.get(0) + ", not the first pushed item");

        Stack good = new Stack();
        good.push(1);
        good.push(2);
        // good.add(0, 99);                 // COMPILE ERROR: Stack has no add method
        System.out.println("Good stack pop: " + good.pop());
        System.out.println("Good stack peek: " + good.peek());
    }
}
