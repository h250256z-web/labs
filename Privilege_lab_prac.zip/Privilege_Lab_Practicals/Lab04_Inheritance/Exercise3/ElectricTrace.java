/*
 * Lab 4 - Exercise 3 (Intermediate): constructor order in a multilevel hierarchy
 * Author: Privilege
 */
class Vehicle {
    Vehicle() { System.out.println("Vehicle constructor"); }
}

class Car extends Vehicle {
    Car() { System.out.println("Car constructor"); }   // super() is added automatically
}

class ElectricCar extends Car {
    ElectricCar() { System.out.println("ElectricCar constructor"); }
}

public class ElectricTrace {
    public static void main(String[] args) {
        // PREDICTION: Vehicle, then Car, then ElectricCar, from the top of the chain down
        System.out.println("Creating an ElectricCar:");
        new ElectricCar();
    }
}
