/*
 * Lab 4 - Exercise 4 (Intermediate): why Dog does not compile with only Animal(String)
 * Author: Privilege
 *
 * The broken version is kept in comments so this file still compiles.
 *
 *   class Animal {
 *       Animal(String name) { ... }      // no no-argument constructor
 *   }
 *   class Dog extends Animal {
 *       Dog() { }                        // compile error: the implicit super() has no match
 *   }
 *
 * WHY: every constructor starts with a call to a superclass constructor. If I do not
 * write one, Java inserts super() with no arguments. Animal has none, so there is nothing to call.
 *
 * FIX: pass the name on explicitly.
 */
class Animal {
    String name;

    Animal(String name) {
        this.name = name;
    }
}

class Dog extends Animal {
    Dog(String name) {
        super(name);        // EXPLAIN: an explicit call that matches Animal's constructor
    }
}

public class DogAnimal {
    public static void main(String[] args) {
        Dog d = new Dog("Rex");
        System.out.println("The dog is called " + d.name);
    }
}
