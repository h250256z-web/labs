/*
 * Lab 4 - Exercise 2 (Basic): Teacher and Student share the Person code
 * Author: Privilege
 */
class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void display() {
        System.out.println("Name: " + name + ", age " + age);
    }
}

class Student extends Person {
    String course;
    Student(String name, int age, String course) {
        super(name, age);
        this.course = course;
    }
}

class Teacher extends Person {
    String subject;
    Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }
}

public class PeopleShareCode {
    public static void main(String[] args) {
        // EXPLAIN: one array of the parent type holds both subclasses,
        // and the display() code is written only once, in Person
        Person[] people = {
            new Student("Privilege", 20, "OOP"),
            new Teacher("Mrs Chirwa", 38, "Databases")
        };
        for (Person p : people) {
            p.display();
        }
    }
}
