/*
 * Lab 3 - Exercise 4 (Intermediate): an immutable Person
 * Author: Privilege
 *
 * Design choices (explained in the comments below):
 *  - the class is final, so a subclass cannot add mutable state
 *  - every field is private and final, so each value is set once
 *  - there are no setters, so nothing can change after construction
 *  - "changing" a value returns a NEW object instead
 */
final class ImmutablePerson {
    private final String name;   // final: assigned once in the constructor
    private final int age;

    ImmutablePerson(String name, int age) {
        if (age < 0) throw new IllegalArgumentException("Age cannot be negative");
        this.name = name;
        this.age = age;
    }

    public String getName() { return name; }
    public int getAge()     { return age; }

    // EXPLAIN: returns a new object, leaving this one untouched
    public ImmutablePerson withAge(int newAge) {
        return new ImmutablePerson(name, newAge);
    }

    @Override
    public String toString() { return name + " (" + age + ")"; }
}

public class ImmutablePersonDemo {
    public static void main(String[] args) {
        ImmutablePerson original = new ImmutablePerson("Privilege", 20);
        ImmutablePerson birthday = original.withAge(21);

        System.out.println("Original: " + original);   // still 20
        System.out.println("Updated:  " + birthday);   // 21, a different object
        System.out.println("Same object? " + (original == birthday));
    }
}
