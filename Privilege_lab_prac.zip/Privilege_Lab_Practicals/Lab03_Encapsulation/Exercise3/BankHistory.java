/*
 * Lab 3 - Exercise 3 (Intermediate): BankAccount with a transaction history
 * Author: Privilege
 */
import java.util.ArrayList;
import java.util.List;

class BankAccount {
    private final String owner;
    private double balance;
    private final List<String> history = new ArrayList<>();   // private, so outside code cannot touch it

    BankAccount(String owner) {
        this.owner = owner;
    }

    void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
        balance += amount;
        history.add("deposit " + amount);
    }

    boolean withdraw(double amount) {
        if (amount > balance) {
            history.add("refused withdrawal " + amount);
            return false;
        }
        balance -= amount;
        history.add("withdraw " + amount);
        return true;
    }

    // EXPLAIN: List.copyOf makes an unmodifiable copy, so the caller cannot change our history
    List<String> getHistory() {
        return List.copyOf(history);
    }

    double getBalance() { return balance; }
}

public class BankHistory {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount("Privilege");
        acc.deposit(500);
        acc.withdraw(120);
        acc.withdraw(1000);   // refused, but still recorded

        System.out.println("Balance: " + acc.getBalance());
        for (String entry : acc.getHistory()) {
            System.out.println("  " + entry);
        }

        try {
            acc.getHistory().clear();   // try to tamper with the history
        } catch (UnsupportedOperationException e) {
            System.out.println("History is read-only from outside");
        }
        System.out.println("Entries still recorded: " + acc.getHistory().size());
    }
}
