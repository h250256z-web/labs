/*
 * Lab 3 - Exercise 2 (Basic): getGrade() calculated from marks, not stored
 * Author: Privilege
 */
class Student {
    private final String name;
    private final int marks;

    Student(String name, int marks) {
        this.name = name;
        this.marks = marks;
    }

    // EXPLAIN: the grade is worked out each time from marks, so it can never be out of step
    public String getGrade() {
        if (marks >= 80) return "A";
        if (marks >= 70) return "B";
        if (marks >= 60) return "C";
        return "F";   // this sketch uses 60 as the pass mark; anything below is F
    }

    public String getName() { return name; }
}

public class GradeDemo {
    public static void main(String[] args) {
        int[] testMarks = {95, 80, 79, 70, 69, 60, 59, 0};
        for (int m : testMarks) {
            Student s = new Student("Student " + m, m);
            System.out.println(s.getName() + " -> " + s.getGrade());
        }
    }
}
