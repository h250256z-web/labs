/*
 * Lab 3 - Exercise 1 (Basic): Student with validated marks
 * Author: Privilege
 */
class Student {
    private String name;
    private int marks;   // EXPLAIN: private, so only the setter can change it

    Student(String name) {
        this.name = name;
    }

    public String getName() { return name; }
    public int getMarks()   { return marks; }

    // EXPLAIN: the setter is the only door in; it rejects marks outside 0 to 100
    public void setMarks(int marks) {
        if (marks < 0 || marks > 100) {
            throw new IllegalArgumentException("Marks must be 0 to 100, got " + marks);
        }
        this.marks = marks;
    }
}

public class StudentMarks {
    public static void main(String[] args) {
        Student s = new Student("Privilege");
        s.setMarks(74);
        System.out.println(s.getName() + " has " + s.getMarks());

        try {
            s.setMarks(120);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
        System.out.println("Marks still " + s.getMarks());
    }
}
