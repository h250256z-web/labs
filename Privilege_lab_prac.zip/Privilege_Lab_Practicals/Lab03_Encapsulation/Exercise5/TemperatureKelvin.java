/*
 * Lab 3 - Exercise 5 (Challenge): store kelvin inside, convert on the way out
 * Author: Privilege
 */
class Temperature {
    private static final double ABSOLUTE_ZERO_C = -273.15;

    // EXPLAIN: the internal unit is kelvin. Callers never see this field directly,
    // so I could change it later (for example to Celsius) without breaking them.
    private final double kelvin;

    private Temperature(double kelvin) {
        this.kelvin = kelvin;
    }

    static Temperature fromCelsius(double c) {
        if (c < ABSOLUTE_ZERO_C) {
            throw new IllegalArgumentException("Below absolute zero: " + c + " C");
        }
        return new Temperature(c - ABSOLUTE_ZERO_C);
    }

    double getKelvin()     { return kelvin; }
    double getCelsius()    { return kelvin + ABSOLUTE_ZERO_C; }
    double getFahrenheit() { return getCelsius() * 9.0 / 5.0 + 32; }
}

public class TemperatureKelvin {
    public static void main(String[] args) {
        Temperature t = Temperature.fromCelsius(25);
        System.out.printf("%.2f K = %.2f C = %.2f F%n",
                t.getKelvin(), t.getCelsius(), t.getFahrenheit());

        try {
            Temperature.fromCelsius(-300);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
    }
}
