/*
 * Lab 1 - Exercise 4 (Intermediate): predict, then run, a change through an alias
 * Author: Privilege
 */
class Rectangle {
    double width;
    double height;

    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }
}

public class AliasPrediction {
    public static void main(String[] args) {
        // PREDICTION (written before running): r1.width will print 4.0
        // because r2 looks like a separate copy.
        Rectangle r1 = new Rectangle(4, 5);
        Rectangle r2 = r1;            // copies the REFERENCE, not the object
        r2.width = 10;

        // RESULT: 10.0, so my prediction was wrong.
        // EXPLAIN: r1 and r2 both point at the same Rectangle object.
        System.out.println("r1.width = " + r1.width);
        System.out.println("r2.width = " + r2.width);
        System.out.println("same object? " + (r1 == r2));
    }
}
