/*
 * Lab 1 - Exercise 1 (Basic): a Car class with a display method
 * Author: Privilege
 */
class Car {
    // EXPLAIN: each car keeps its own copy of these three fields
    String brand;
    int year;
    int mileage;

    Car(String brand, int year, int mileage) {
        this.brand = brand;
        this.year = year;
        this.mileage = mileage;
    }

    void display() {
        System.out.println(brand + " (" + year + ") - " + mileage + " km");
    }
}

public class CarDemo {
    public static void main(String[] args) {
        // Three separate objects, each created with new
        Car[] cars = {
            new Car("Toyota", 2015, 120000),
            new Car("Honda", 2008, 185000),
            new Car("Mazda", 2019, 42000)
        };
        for (Car c : cars) {
            c.display();
        }
    }
}
