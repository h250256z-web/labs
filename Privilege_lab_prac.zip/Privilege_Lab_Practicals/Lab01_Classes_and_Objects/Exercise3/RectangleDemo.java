/*
 * Lab 1 - Exercise 3 (Intermediate): find the rectangle with the largest area
 * Author: Privilege
 */
class Rectangle {
    double width;
    double height;

    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    double area()      { return width * height; }
    double perimeter() { return 2 * (width + height); }

    @Override
    public String toString() {
        return "Rectangle " + width + " x " + height;
    }
}

public class RectangleDemo {
    public static void main(String[] args) {
        Rectangle[] shapes = {
            new Rectangle(2, 3),
            new Rectangle(7, 4),
            new Rectangle(5, 5),
            new Rectangle(1, 10),
            new Rectangle(6, 2)
        };

        // EXPLAIN: keep a reference to the biggest one seen so far
        Rectangle biggest = shapes[0];
        for (Rectangle r : shapes) {
            if (r.area() > biggest.area()) {
                biggest = r;
            }
        }
        System.out.println("Largest: " + biggest + " area " + biggest.area());
        System.out.println("Its perimeter: " + biggest.perimeter());
    }
}
