/*
 * Lab 1 - Exercise 5 (Challenge): Person has an Address
 * Author: Privilege
 */
class Address {
    String street;
    String city;

    Address(String street, String city) {
        this.street = street;
        this.city = city;
    }
}

class Person {
    String name;
    Address address;   // EXPLAIN: a field that refers to another object

    Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }
}

public class PersonAddress {
    public static void main(String[] args) {
        Person p = new Person("Privilege", new Address("12 Main Road", "Bindura"));

        // Chained dot expression: person -> address -> city
        System.out.println(p.name + " lives in " + p.address.city);

        // A person with no address: the reference is null
        Person nomad = new Person("Tendai", null);
        try {
            // EXPLAIN: reading a field through a null reference throws NullPointerException
            System.out.println(nomad.address.city);
        } catch (NullPointerException e) {
            System.out.println("No address on record for " + nomad.name);
        }

        // Safer: check for null before using the reference
        if (nomad.address != null) {
            System.out.println(nomad.address.city);
        } else {
            System.out.println("Checked first: no address for " + nomad.name);
        }
    }
}
