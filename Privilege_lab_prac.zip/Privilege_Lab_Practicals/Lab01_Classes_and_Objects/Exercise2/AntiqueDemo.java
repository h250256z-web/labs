/*
 * Lab 1 - Exercise 2 (Basic): isAntique() for a car
 * Author: Privilege
 */
class Car {
    String brand;
    int year;
    int mileage;

    Car(String brand, int year, int mileage) {
        this.brand = brand;
        this.year = year;
        this.mileage = mileage;
    }

    // EXPLAIN: I pass the current year in, so the result does not change every day
    boolean isAntique(int currentYear) {
        return currentYear - year > 25;   // more than 25 years old
    }
}

public class AntiqueDemo {
    public static void main(String[] args) {
        int thisYear = 2026;
        Car old = new Car("Peugeot", 1995, 210000);   // 31 years old
        Car newer = new Car("Honda", 2005, 150000);   // 21 years old

        System.out.println(old.brand + " antique? " + old.isAntique(thisYear));
        System.out.println(newer.brand + " antique? " + newer.isAntique(thisYear));
    }
}
