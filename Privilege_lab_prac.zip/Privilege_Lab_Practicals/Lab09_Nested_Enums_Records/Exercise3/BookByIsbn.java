/*
 * Lab 9 - Exercise 3 (Intermediate): Book equality by ISBN
 * Author: Privilege
 */
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

class Book {
    private final String isbn;
    private final String title;

    Book(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    // Two books are the same book if their ISBNs match, whatever the title says
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book other)) return false;
        return isbn.equals(other.isbn);
    }

    // EXPLAIN: hashCode uses the same field as equals, so equal books hash the same
    @Override
    public int hashCode() { return Objects.hash(isbn); }

    @Override
    public String toString() { return title + " [" + isbn + "]"; }
}

public class BookByIsbn {
    public static void main(String[] args) {
        Set<Book> shelf = new HashSet<>();
        shelf.add(new Book("978-0", "Clean Code"));
        shelf.add(new Book("978-0", "Clean Code (2nd copy)"));   // same ISBN: refused
        shelf.add(new Book("978-1", "Effective Java"));

        System.out.println("Books on the shelf: " + shelf.size());   // 2
        System.out.println(shelf.contains(new Book("978-1", "anything")));  // true
    }
}
