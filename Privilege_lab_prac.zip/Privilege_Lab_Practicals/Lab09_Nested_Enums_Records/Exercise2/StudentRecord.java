/*
 * Lab 9 - Exercise 2 (Basic): a record for a student
 * Author: Privilege
 */
record Student(String name, int age) {}

public class StudentRecord {
    public static void main(String[] args) {
        Student s = new Student("Privilege", 20);
        System.out.println(s);                                  // generated toString
        System.out.println("Name from accessor: " + s.name());  // components read as methods

        Student same = new Student("Privilege", 20);
        System.out.println("Equal values? " + s.equals(same));  // generated equals
        System.out.println("Same object?  " + (s == same));
    }
}
