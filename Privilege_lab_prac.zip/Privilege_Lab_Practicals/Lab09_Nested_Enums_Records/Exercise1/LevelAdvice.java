/*
 * Lab 9 - Exercise 1 (Basic): an enum with advice for each level
 * Author: Privilege
 */
enum Level { LOW, MEDIUM, HIGH }

public class LevelAdvice {
    static String adviceFor(Level level) {
        return switch (level) {
            case LOW    -> "Keep going, you are on track.";
            case MEDIUM -> "Review your notes this week.";
            case HIGH   -> "Take a break and then plan your next step.";
        };   // no default needed: every constant is covered
    }

    public static void main(String[] args) {
        for (Level l : Level.values()) {
            System.out.println(l + ": " + adviceFor(l));
        }
    }
}
