/*
 * Lab 9 - Exercise 4 (Intermediate): a small list with a nested Node and an inner Iterator
 * Author: Privilege
 */
import java.util.Iterator;

class MyList<T> implements Iterable<T> {

    // static nested class: a Node does not need a MyList object to exist
    private static class Node<T> {
        T value;
        Node<T> next;
        Node(T value) { this.value = value; }
    }

    private Node<T> head;
    private Node<T> tail;

    void add(T value) {
        Node<T> node = new Node<>(value);
        if (head == null) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
    }

    // inner class: each iterator reads the list it belongs to
    @Override
    public Iterator<T> iterator() {
        return new ListIterator();
    }

    private class ListIterator implements Iterator<T> {
        private Node<T> current = head;

        @Override public boolean hasNext() { return current != null; }

        @Override
        public T next() {
            T value = current.value;
            current = current.next;
            return value;
        }
    }
}

class MyListDemo {
    public static void main(String[] args) {
        MyList<String> list = new MyList<>();
        list.add("alpha");
        list.add("beta");
        list.add("gamma");

        // Works in a for-each loop because MyList implements Iterable
        for (String s : list) {
            System.out.println(s);
        }
    }
}
