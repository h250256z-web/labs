/*
 * Lab 9 - Exercise 5 (Challenge): fewest coins for an amount (greedy method)
 * Author: Privilege
 */
enum Coin {
    QUARTER(25), DIME(10), NICKEL(5), PENNY(1);   // largest first, which the greedy method needs

    private final int cents;
    Coin(int cents) { this.cents = cents; }
    int cents()     { return cents; }
}

public class CoinChange {

    // EXPLAIN: take the biggest coin that still fits, again and again.
    // This gives the fewest coins for US coins. It is not always right for every set of coins.
    static void makeChange(int amount) {
        int remaining = amount;
        int count = 0;
        System.out.print(amount + " cents:");
        for (Coin c : Coin.values()) {
            while (remaining >= c.cents()) {
                remaining -= c.cents();
                count++;
                System.out.print(" " + c);
            }
        }
        System.out.println("  (" + count + " coins)");
    }

    public static void main(String[] args) {
        makeChange(41);    // QUARTER, DIME, PENNY
        makeChange(99);
        makeChange(30);
    }
}
