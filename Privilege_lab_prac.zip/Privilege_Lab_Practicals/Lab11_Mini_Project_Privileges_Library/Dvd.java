/*
 * Privilege's Library - a DVD that can be borrowed for 7 days
 * Author: Privilege
 */

public class Dvd extends LibraryItem {

    private final int runningMinutes;

    public Dvd(String id, String title, int runningMinutes) {
        super(id, title);
        if (runningMinutes <= 0) {
            throw new IllegalArgumentException("Running time must be positive");
        }
        this.runningMinutes = runningMinutes;
    }

    @Override
    public int loanPeriodDays() { return 7; }   // DVDs are lent for a shorter time than books

    @Override
    public String typeCode() { return "DVD"; }

    @Override
    public String extraField() { return String.valueOf(runningMinutes); }

    public int getRunningMinutes() { return runningMinutes; }

    @Override
    public String toString() {
        return super.toString() + " (" + runningMinutes + " min)";
    }
}
