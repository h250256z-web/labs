/*
 * Privilege's Library - abstract base class for every item the library lends
 * Author: Privilege
 */

import java.time.LocalDate;

/**
 * EXPLAIN: abstract class - shared state and behaviour for Book and Dvd.
 * Subclasses must say how long they can be lent (loanPeriodDays) and how they
 * are stored in the CSV file (typeCode and extraField).
 */
public abstract class LibraryItem implements Borrowable {

    // EXPLAIN: encapsulation - no public setters; state changes only through borrow/giveBack
    private final String id;
    private final String title;
    private boolean available = true;
    private Loan currentLoan;          // null when the item is on the shelf

    protected LibraryItem(String id, String title) {
        this.id = Validation.text(id, "Item id");
        this.title = Validation.text(title, "Title");
    }

    /** Days the item may be kept. Each subclass decides this (polymorphism). */
    public abstract int loanPeriodDays();

    /** Short code written to the CSV file, for example BOOK or DVD. */
    public abstract String typeCode();

    /** The type-specific value written to the CSV file, for example the author. */
    public abstract String extraField();

    @Override
    public void borrow(Member member, LocalDate loanDate)
            throws ItemNotAvailableException, MemberLimitExceededException {
        // Checks come first, so a failed borrow leaves the item and member unchanged
        if (!available) {
            throw new ItemNotAvailableException("'" + title + "' is already on loan");
        }
        if (!member.canBorrow()) {
            throw new MemberLimitExceededException(member.getName() + " already has "
                    + Member.MAX_LOANS + " loans");
        }
        currentLoan = new Loan(this, member, loanDate, loanDate.plusDays(loanPeriodDays()));
        available = false;
        member.addLoan(currentLoan);
    }

    @Override
    public void giveBack() {
        if (currentLoan == null) {
            throw new IllegalStateException("'" + title + "' is not on loan");
        }
        currentLoan.getMember().removeLoan(currentLoan);
        currentLoan = null;
        available = true;
    }

    public String getId()        { return id; }
    public String getTitle()     { return title; }
    public boolean isAvailable() { return available; }
    public Loan getCurrentLoan() { return currentLoan; }

    @Override
    public String toString() {
        return String.format("[%s] %s | %s | %s", typeCode(), id, title,
                available ? "available" : "on loan");
    }
}
