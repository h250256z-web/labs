/*
 * Privilege's Library - the core service that holds all items and members
 * Author: Privilege
 */

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Library {

    // EXPLAIN: Maps keyed by id, as the manual requires; lookups by id are fast
    private final Map<String, LibraryItem> items = new HashMap<>();
    private final Map<String, Member> members = new HashMap<>();

    public void addItem(LibraryItem item) {
        if (items.containsKey(item.getId())) {
            throw new IllegalArgumentException("Duplicate item id: " + item.getId());
        }
        items.put(item.getId(), item);
    }

    public void registerMember(Member member) {
        if (members.containsKey(member.getId())) {
            throw new IllegalArgumentException("Duplicate member id: " + member.getId());
        }
        members.put(member.getId(), member);
    }

    /** Borrows an item for a member, dated today. */
    public void borrow(String memberId, String itemId)
            throws ItemNotAvailableException, MemberLimitExceededException {
        borrow(memberId, itemId, LocalDate.now());
    }

    /** Borrows an item for a member on a given date (used by tests and when loading saved data). */
    public void borrow(String memberId, String itemId, LocalDate loanDate)
            throws ItemNotAvailableException, MemberLimitExceededException {
        LibraryItem item = findItem(itemId);
        Member member = findMember(memberId);
        item.borrow(member, loanDate);     // the item checks availability and the member's limit
    }

    public void giveBack(String itemId) {
        findItem(itemId).giveBack();
    }

    /** Every loan whose due date is before the given day, earliest due date first. */
    public List<Loan> overdueLoans(LocalDate today) {
        return members.values().stream()                         // stream over members
            .flatMap(m -> m.getActiveLoans().stream())           // their loans, as one stream
            .filter(loan -> loan.isOverdue(today))
            .sorted(Comparator.comparing(Loan::getDueDate))
            .toList();
    }

    /** Case-insensitive title search, sorted by title. */
    public List<LibraryItem> searchByTitle(String text) {
        if (text == null) {
            throw new IllegalArgumentException("Search text is required");
        }
        String wanted = text.toLowerCase();
        return items.values().stream()
            .filter(i -> i.getTitle().toLowerCase().contains(wanted))
            .sorted(Comparator.comparing(LibraryItem::getTitle))
            .toList();
    }

    public List<LibraryItem> allItems() {
        return items.values().stream()
            .sorted(Comparator.comparing(LibraryItem::getId))
            .toList();
    }

    public List<Member> allMembers() {
        return members.values().stream()
            .sorted(Comparator.comparing(Member::getId))
            .toList();
    }

    private LibraryItem findItem(String itemId) {
        LibraryItem item = items.get(itemId);
        if (item == null) {
            throw new IllegalArgumentException("No item with id " + itemId);
        }
        return item;
    }

    private Member findMember(String memberId) {
        Member member = members.get(memberId);
        if (member == null) {
            throw new IllegalArgumentException("No member with id " + memberId);
        }
        return member;
    }
}
