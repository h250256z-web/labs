/*
 * Privilege's Library - a book that can be borrowed for 21 days
 * Author: Privilege
 */

public class Book extends LibraryItem {

    private final String author;

    public Book(String id, String title, String author) {
        super(id, title);                       // EXPLAIN: must run first; sets id and title
        this.author = Validation.text(author, "Author");
    }

    @Override
    public int loanPeriodDays() { return 21; }   // EXPLAIN: overrides the abstract method

    @Override
    public String typeCode() { return "BOOK"; }

    @Override
    public String extraField() { return author; }

    public String getAuthor() { return author; }

    @Override
    public String toString() {
        return super.toString() + " by " + author;   // EXPLAIN: extends the parent's text
    }
}
