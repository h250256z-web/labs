/*
 * Privilege's Library - thrown when someone tries to borrow an item that is already on loan
 * Author: Privilege
 */

// EXPLAIN: checked exception - the caller must catch it or declare it
public class ItemNotAvailableException extends Exception {
    private static final long serialVersionUID = 1L;   // EXPLAIN: required by the Serializable warning; not used for saving
    public ItemNotAvailableException(String message) {
        super(message);
    }
}
