/* Author: Privilege */

/**
 * Exercise 4 (Intermediate): two static blocks and two instance blocks.
 *
 * STEP 1 - PREDICT the output before you run the program.
 * STEP 2 - Run it in VS Code (Run above main) and compare with your prediction.
 *
 * Rules to apply:
 *  - Static fields and static blocks run ONCE, when the class is loaded,
 *    in the order they are written.
 *  - Instance field initialisers and instance blocks run for EVERY new object,
 *    in the order they are written, BEFORE the constructor body.
 *
 * My prediction (fill in / compare):
 *   static block 1
 *   static field x
 *   static block 2
 *   instance field a
 *   instance block 1
 *   instance block 2
 *   constructor
 *   instance field a
 *   instance block 1
 *   instance block 2
 *   constructor
 */
public class InitPuzzle {

    // Static part 1: a static block (runs first, because it is written first)
    static {
        System.out.println("static block 1");
    }

    // Static part 2: a static field whose initialiser prints something
    static int x = log("static field x");

    // Static part 3: a second static block
    static {
        System.out.println("static block 2");
    }

    // Instance part 1: an instance field whose initialiser prints something
    int a = log("instance field a");

    // Instance part 2: an instance block
    {
        System.out.println("instance block 1");
    }

    // Instance part 3: a second instance block
    {
        System.out.println("instance block 2");
    }

    // Constructor body: runs last for every object
    public InitPuzzle() {
        System.out.println("constructor");
    }

    // Helper that prints a message and returns a value so it can initialise a field
    static int log(String message) {
        System.out.println(message);
        return 0;
    }

    public static void main(String[] args) {
        System.out.println("--- first object ---");
        new InitPuzzle();     // static parts already ran during class loading

        System.out.println("--- second object ---");
        new InitPuzzle();     // static parts do NOT run again
    }
}
